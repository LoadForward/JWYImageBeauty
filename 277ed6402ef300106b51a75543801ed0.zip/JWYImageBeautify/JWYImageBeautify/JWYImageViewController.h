//
//  JWYImageViewController.h
//  JWYImageBeautify
//
//  Created by SoSee_Tech_01 on 17/3/1.
//  Copyright © 2017年 SoSee_Tech_01. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JWYImageViewController : UIViewController

@end
